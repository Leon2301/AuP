trait Necklace {
    fn get_len(self) -> usize; 
    fn is_valid(self) -> bool;
    fn is_identical_with(self, other: Self) -> bool; 
}

impl Necklace for [(u8,u8,u8);20] {
    // gibt die Anzahl der Elemente die nicht (0,0,0) sind.
    fn get_len(self) -> usize {
        count_chain_elements(self, 0)
    }

    // gibt false, falls es mehrere Lücken gibt, sonst true
    fn is_valid(self) -> bool {
        // wenn es mehr als eine große Lücke gibt, wird ein false zurückgegeben. 
        if count_emty_spaces(self, 0, false) > 1 {
            false
        } else {
            true
        }
    }

    // gibt true, wenn es eine ähnliche Varianten sind, sonst false
    fn is_identical_with(self, other: Self) -> bool {
        // Vergleicht auf: Identisch, rotiert, gespiegelt, rotiert & gespiegelt. 
        compare_with(self, other, 0)
    }
}

// --- Hilfsfunktionen ---

// zählt die zusammenhängenden Lücken
// chain ist das Perlenketten Array, idx ist der Index im Array, space_before gibt an ob davor schon eine Lücke war. 
fn count_emty_spaces(chain: [(u8,u8,u8);20], idx: usize, space_before: bool) -> i8 {
    // Abbruchbedingung. 
    if idx == chain.len() -1 {
        // schaut ob das letzte Element leer ist.
        if chain[idx] == (0,0,0) {
            // schaut ob auch das erste Elemnt leer ist.
            if chain[0] == (0,0,0) {
                // schaut ob das Element davor schon leer war, falls ja wurde eine Lücke zu viel gezählt. 
                if space_before {
                    -1
                } else {
                    0
                }
            } else {
                // schaut ob das Element davor schon leer war. 
                if space_before {
                    0
                } else {
                    1
                }
            }
        } else { 
            // Perle an dieser Stelle
            0
        }
    } else {
        // Beginn des Rekursionsschrittes
        if chain[idx] == (0,0,0) {
            // schaut ob das Element davor schon leer war.
            if space_before {
                // wir befinden uns noch in der selben Lücke.
                0 + count_emty_spaces(chain, idx+1, true)
            } else {
                1 + count_emty_spaces(chain, idx+1, true)
            }
        } else {
            // Perle an dieser Stelle
            0 + count_emty_spaces(chain, idx+1, false)
        }
    }
}

fn count_chain_elements(chain: [(u8,u8,u8);20], idx: usize) -> usize{
    // Abbruchbedingung: am Ende von chain
    if idx == chain.len() -1 {
        // Wenn das Element nicht leer ist addiere 1, ansonstn null
        if chain[idx] == (0,0,0) {
            0
        } else {
            1
        }
    // Rekursionsschritt
    } else {
        // Wenn das Element nicht leer ist addiere 1, ansonstn null
        if chain[idx] == (0,0,0) {
            0 + count_chain_elements(chain, idx+1)
        } else {
            1 + count_chain_elements(chain, idx+1)
        }
    }
}

// Vergleicht chain mit other. Wobei other rotiert ist um rotated_by. 
fn compare_with(chain: [(u8,u8,u8);20], other: [(u8,u8,u8);20], rotated_by: usize) -> bool {
    // Abbruchbedingung, bei der die aufgerufene Funktion direkt das Ergebnis weitergibt.
    if rotated_by == other.len() -1 {
        compare_with_helper(chain, other, rotated_by, 0)
    } else {
        // Wenn hier ein übereinstimmung gefunden wurde, wird direkt true zurückgegeben, ansonsten probieren wir es weiter. 
        if compare_with_helper(chain, other, rotated_by, 0) == true {
            true
        } else {
            // rekursiver Aufruf, wobei die Rotation um eine Stelle weiter geschoben wird.
            compare_with(chain, other, rotated_by+1)
        }
    }
}

// Wir gehen hier wieder rekursiv durch und vergleichen die Einträge nacheinander. 
fn compare_with_helper(chain: [(u8,u8,u8);20], other: [(u8,u8,u8);20], rotated_by: usize, idx: usize) -> bool {
    // Abbruchbedingung: wenn der Index durch alle Elemente einmal durch ist. 
    if idx == chain.len() -1 {
        // Hier vergleichen wir mit other. Wenn wir über die Länge des Arrays hinausgehen, 
        // springen wir mit % wieder nach vorne: z.B idx = 19  --> [19] == [(19+1) % 20 = 0]
        if chain[idx] == other[(idx + rotated_by)%(other.len())] {
            true
        // hier testet er außerdem noch die Spiegelung.
        // Dafür Ziehen wir einfach den aktuellen Index vom Masimalen ab.  
        } else if chain[idx] == other[other.len() -1 - (idx + rotated_by)%(other.len())]{
            true
        }else {
            false
        }
    } else {
        // Vergleicht wieder rotierte Variante.
        if chain[idx] == other[(idx + rotated_by)%(other.len())] {
            compare_with_helper(chain, other, rotated_by, idx+1)
        // Vergleicht wieder rotiert gespiegelte Variante. 
        } else if chain[idx] == other[other.len() -1 - (idx + rotated_by)%(other.len())]{
            compare_with_helper(chain, other, rotated_by, idx+1)
        // Wenn bereits ein Element nicht übereinstimmt ist der gesmate Vergleich false. 
        }else {
            false
        }
    }
}
